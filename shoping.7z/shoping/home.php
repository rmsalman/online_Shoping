<?php
include('include/connect.php');
include('include/header.php');
?>
<div class="container">
	

	<?php


	if(isset($_POST["description"])){
		$name = $_POST["name"];
		$description = $_POST["description"];
		$filename= $_FILES["uploadfile"] ["name"];
	    $tempname= $_FILES["uploadfile"] ["tmp_name"];
		$folder=  'upload/'.$filename;
        move_uploaded_file($tempname, $folder);

		$sql = "INSERT INTO `products`( `name`, `description` ,`room_pic` ) VALUES ('$name','$description','$filename')";
			if ($conn->query($sql) === TRUE) {     
			//    echo "New record created successfully";
			} else {
			    echo "Error: " . $sql . "<br>" . $conn->error;
			}
}


				$sql = "SELECT * FROM `products`";
				$result = $conn->query($sql);
                 if ($result->num_rows > 0) {

					 ?> 
               <div class="row">
				     <?php
					 while($row = $result->fetch_assoc()) {

					 	?>
					 	<div class="col-sm-4">
					 	<div class="card">
					<img src="upload/<?php echo $row['room_pic'] ; ?> " height='100' width='100'  alt="" class="card-img-top">

					 		<div class="card-body">
					 	<div class="card-title"><strong><?php echo $row["name"]; ?></strong></div>	
					    <div class="card-text"> <?php echo $row["description"] ; ?></div>
						<a  class="btn btn-primary"
						 href='order.php?product_id=<?php echo $row["id"]; ?>'>Orders</a>
                         <br>
                         <br>
						     <?php        
						if (isset($_SESSION['role']) && $_SESSION['role'] == 1){
                             ?>
							<a  class="btn btn-success"	href='update.php?id=<?php echo $row["id"]; ?>'>update</a>
								
						    <a class="btn btn-danger" href='delete.php?id=<?php echo $row["id"]; ?>'>Delete</a>
                   <?php } ?>
                            </div>
                     </div>
                     
                        </div> 
	                <?php

					
                      
					}
					?>
				</div>
					<?php
					} else {
					    echo "0 results";
					}
				
	                ?>
      
</div>










<div class="container">
<br>
<h2>Products</h2>


	<form class="form" action="" method="POST" enctype="multipart/form-data" >
		
	  <div class="form-group">
	    <label>Name</label>
	    <input type="text" name="name" class="form-control" placeholder="title">
	  </div>
	  <div class="form-group">
	    <label> Description</label>
	    <textarea class="form-control" name="description"  placeholder="Add Description"></textarea>
	  </div>
	  <div class="form-group">
	    <label for="room_pic">room Picture</label>
	    <input type="file" required="required" name="uploadfile"  >
	  </div>
	
	   <button type="submit" name="submit" value="submit" class="btn btn-primary" >Submit</button>
	</form>

</div>





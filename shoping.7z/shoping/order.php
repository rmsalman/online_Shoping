<?php
include('include/connect.php');
include('include/header.php');
?>

<?php

    
     
    if(isset($_GET['city'])){
    $lk=$_GET['country'];
    $rlk=$_GET['city'];
    $lfk=$_GET['adress'];
    $gdf=$_GET['number'];
    $ff=$_GET['ordid'];
    $sql="UPDATE `orders` SET `adress`='$lfk',`city`='$rlk',`country`='$lk',`number`='$gdf' WHERE `orders`.`id` = '$ff' ";

      if (mysqli_query($conn, $sql)) {
	   			 echo "data updated";
		} else {
		    echo "Error updating record: " . mysqli_error($conn);
		}
   }



     if(isset($_GET['status_by_user'])){
   	
   	$dd=$_GET['status_by_user'];
   	$de=$_GET['ord_id'];
   	$sql="UPDATE `orders` SET `aprv_by_status` = '$dd' WHERE `orders`.`id` = '$de' ";
    		
		if (mysqli_query($conn, $sql)) {
	   			 echo "data updated";
		} else {
		    echo "Error updating record: " . mysqli_error($conn);
		}

   }




      if(isset($_GET['status_by_admin'])){

        $ff=$_GET['status_by_admin'];
        $fd=$_GET['ord_id'];
      	$sql="UPDATE `orders` SET `aprv_by_admin` = '$ff' WHERE `orders`.`id` = '$fd' ";
    		
		if (mysqli_query($conn, $sql)) {
	   			 echo "data updated";
		} else {
		    echo "Error updating record: " . mysqli_error($conn);
		}

      }
     


    if(isset($_GET['product_id']) && $_SESSION['id']){
    	$product_id=$_GET["product_id"];
    	$user_id=$_SESSION["id"];
    	
    $sql="INSERT INTO `orders`( `user_id`, `product_id`)
          VALUES ('$user_id','$product_id')";
	        if (mysqli_query($conn, $sql)) {

			    echo "New record created successfully";
			    } else {
			    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
			    }

    }



    if(isset($_SESSION['id'])){
      $akk=$_SESSION['id'];
    $sql = "SELECT * ,
orders.id as ordid,
     users.id as uid ,
     products.id as pid ,
     users.name as uname ,
     products.name as pname
      FROM `orders` 
      JOIN users 
      on orders.user_id = users.id 
      JOIN products 
      on orders.product_id = products.id";
             
            ?>
   <table class="table table-bordered">
	<thead ">
		<tr>
			<th>order id</th>
			<th>user_id</th>

			<th>product_id</th>
			<th>email</th>
			<th>password</th>
			<th>role</th>
			<th>uname</th>
			<th>description</th>
      <th>pname</th>
      <th>uid</th>
      <th>pname</th>
      <th>form</th>
      <th>img</th>
      <th>admin</th>
			<th>aprv_by_status</th>
			<th>aprv_by_admin</th>
       
			
			



		
		</tr>
	</thead>
	<tbody>
             <?php

			$result = mysqli_query($conn, $sql);

			if (mysqli_num_rows($result) > 0) {
				?>
		            
					
			   <?php
			    // output data of each row
		            while($row = mysqli_fetch_assoc($result)) {




                ?>

             

			  <tr>
			  	<td><?php echo $row['ordid']; ?></td>
         
			 <td><?php echo $row["user_id"]; ?>	</td>
			 	 <td><?php echo $row["product_id"] ; ?></td> 
		       <td> <?php echo $row["email"] ; ?></td>
		       <td> <?php echo $row["password"] ; ?></td>
		       <td> <?php echo $row["role"] ; ?></td>
		       <td> <?php echo $row["uname"] ; ?></td>
		       <td> <?php echo $row["description"] ; ?></td>
		       <td> <?php echo $row["pname"] ; ?></td>
		       <td> <?php echo $row["uid"] ; ?></td>
		       <td> <?php echo $row["pid"] ; ?></td>
		       <td>
		       	<form action="order.php?form=1&ord_id=<?php echo $row['ordid']; ?>" method="GET" >
		       	<input type="number" name="ordid" value="<?php echo $row['id'] ; ?>">
		      <label for="">country:</label> <input type="text" name="country" value="<?php echo $row['country'] ; ?>">  
		      <br>
		      <br> 
		       <label for="">City:</label>   <input type="text" name="city" value="<?php echo $row["city"] ; ?>">  
		      <br> 
		      <label for="">Adress:</label>  <input type="text" name="adress" value="<?php echo $row["adress"] ; ?>"> 
		      <br> 
              <label for="">number</label>  <input type="number" name="number" value="<?php echo $row["number"] ; ?>">  
                        <button type="submit"  class="btn btn-default">submit</button>
                </form>
		       </td>
           <td><img src="upload/<?php echo $row['room_pic'] ; ?> " height='100' width='100' ></td>


		      

		        <?php 
                     if($row["aprv_by_status"] ==1){
                     	echo "<td>Confirmed</td>";
                     }else{ 
                     	echo "<td>Not Confirmed</td>";
                     }


                     if($row["aprv_by_admin"] ==1){
                     	echo "<td>confirmed</td>";
                     }  else{
                     	echo "<td>Not Confirmed</td>";
                     }
                    ?>		       
               
               <?php if($row["aprv_by_status"]==1){
               	      ?>
               	      <td><a href="order.php?status_by_user=0&ord_id=<?php echo $row['ordid']; ?>&update_by_user=1">Not confirmed by user</a></td>
                
              <?php } else{
                        	
                        	?>
                        	<td><a href="order.php?status_by_user=1&ord_id=<?php echo $row['ordid']; ?>&update_by_user=1">Confirm by user</a></td>
                
                       <?php }
                       ?>

                 

              
                  <?php if($row["aprv_by_admin"]==1){
               	      ?>
               	      <td><a href="order.php?status_by_admin=0&ord_id=<?php echo $row['ordid']; ?>&update_by_admin=1">Not Confirmed by admin</a></td>
              <?php } else{
                        	
                        	?>
              <td><a href="order.php?status_by_admin=1&ord_id=<?php echo $row['ordid']?>&update_by_admin=1">Cofirm by admin</a></td>
                       <?php }
                       ?>
 
		       </tr>
		     
		    


 <?php
            }
    
    }
   } else{
        	echo "error";
        }

?>
</tbody>
</table>

<?php
include('include/header.php');
include('include/connect.php');
?>

<?php




if(isset($_GET["logout"])){
	session_destroy();
}



if(isset($_GET["email"])){

	if($_GET["password"] == '' || $_GET["email"] == '' ) {
		echo 'All fields are Requred';
	}
	else 
	{
		$email = $_GET["email"];
		$password = $_GET["password"];
		

		$sql = "SELECT * FROM `users` WHERE email='$email' and password='$password'";
		$result = $conn->query($sql);

		if ($result->num_rows > 0) {
			
                   

		    // output data of each row
		    while($row = $result->fetch_assoc()) {

				$_SESSION['email'] = $row['email'];
				
				$_SESSION['password'] = $row['password'];

				$_SESSION['role'] = $row['role'];
				$_SESSION['id'] = $row['id'];

		    }
		} else {
		    echo "0 results";
		}
	}
}
?>
<!-- <?php

// if (isset($_SESSION['role']) && $_SESSION['role'] == 1){
// 		echo 'you are admin';
// }else{
// 	    echo 'you are not admin';
// }

?> -->


<?php
if (isset($_SESSION['email'])){
	header('location:home.php');
}
?>

	<div class="container">
  
  
	    <form class="form-inline" action="" method="GET">
		    <div class="form-group ">
		      <label for="email">Email:</label>
		      <input type="email" class="form-control" id="email" placeholder="Enter email" name="email">
		    </div>
		     <br>
		     <br>	
		    <div class="form-group ">
		      <label for="pwd">Password:</label>
		      <input type="password" class="form-control" id="pwd" placeholder="Enter password" name="password">
		    </div>
		     <br>
		     
		    <div class="checkbox">
		      <label><input type="checkbox" name="remember"> Remember me</label>
		    </div>
		     <br>
		     <br>
		    <button type="submit" class="btn btn-default">Submit</button>
		</form>
</div>

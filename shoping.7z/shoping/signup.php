<?php 
include('include/connect.php');
include('include/header.php');
?>
 
<?php

if(isset($_GET["logout"])){
     session_destroy();
}



// signUp
if(isset($_POST["email"])){

	

		$password = $_POST["password"];
		$email = $_POST["email"];
		$name = $_POST["name"];
        $role = $_POST["role"];

		$sql = "INSERT INTO 
		`users`( `password`, `email`, `name`, `role`) 
		VALUES ('$password','$email','$name','$role') " ;
         if (mysqli_query($conn, $sql)) {
	            header('location:login.php');
               $_SESSION['loggedin'] = 1;
			   $_SESSION['name'] = $name;
			   $_SESSION['email'] = $email;
			  
			   $_SESSION['role']=2;

				     	         


		} else {
		    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}

}

?>



 
<div class="container">
  
  <form class="form-inline" action="" method="POST">
			    <div class="form-group fs">
			      <label for="email">Name:</label>
			      <input type="text" class="form-control" id="email" placeholder="name" name="name">
			    </div>
        <br>
        <br>	
			    <div class="form-group fs">
			      <label for="email">Email:</label>
			      <input type="email" class="form-control" id="email" placeholder="Enter email" name="email">
			    </div>
    	<br>
    	<br>
		    	<div class="form-group">
			    <label> role</label>
			    <select name="role" class="form-control" >
			    	<option value="1" >admin</option>
			    	<option  value="2">user</option>
			    	
			    </select>
			  </div>
	  <br>
	  <br>		
			    <div class="form-group sf">
			      <label for="pwd">Password:</label>
			      <input type="password" class="form-control" id="pwd" placeholder="Enter password" name="password">
			    </div>
    

        <br>
        <br>
			    <div class="checkbox">
			      <label><input type="checkbox" name="remember"> Remember me</label>
			    </div>
     <br>
        
    <button type="submit" class="btn btn-default">Submit</button>
  </form>

</div>

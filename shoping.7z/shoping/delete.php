

<?php

include('include/header.php');
include('include/connect.php');

?>


<?php

	
	if(isset($_GET["id"])){
       
        
       
				
		    $ee = $_GET["id"]; 
			$sql = "DELETE FROM `products` WHERE id='$ee' ";

			if (mysqli_query($conn, $sql)) {
			   header('location:home.php');
			} else {
			    echo "Error deleting record: " . mysqli_error($conn);
			}
	}

		




   ?>



<div class="container">
<br>
<h2>Product delete</h2>


	<form class="form" action="" method="GET">
		<div class="form-group">
	    <label>id</label>
	    <input type="text" name="id" class="form-control" placeholder="id" >
	  </div> 
	  <div class="form-group">
	    <label>Name</label>
	    <input type="text" name="name" class="form-control" placeholder="name" >
	  </div>
	  <div class="form-group">
	    <label> Description</label>
	    <textarea class="form-control" name="description"  placeholder="Add Description"></textarea>
	  </div>
	
			  <button type="submit" name="submit" class="btn btn-primary">Delete</button>
	</form>

</div>
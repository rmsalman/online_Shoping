-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 03, 2018 at 08:45 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `online_shoping`
--

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `aprv_by_status` int(11) NOT NULL COMMENT 'approve by user',
  `aprv_by_admin` int(11) NOT NULL COMMENT 'approve by admin',
  `adress` varchar(40) NOT NULL,
  `city` varchar(30) NOT NULL,
  `country` varchar(60) NOT NULL,
  `number` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `product_id`, `aprv_by_status`, `aprv_by_admin`, `adress`, `city`, `country`, `number`) VALUES
(5, 5, 13, 1, 1, '', '', '', 0),
(6, 5, 11, 1, 1, '', '', '', 0),
(7, 5, 11, 1, 0, '', '', '', 0),
(8, 1, 8, 0, 0, '', '', '', 0),
(9, 1, 8, 0, 0, '', '', '', 0),
(10, 1, 8, 0, 0, '', '', '', 0),
(11, 1, 8, 0, 0, 'Lahore Pakistan', 'Lahore', 'kjhg', 3232),
(12, 1, 8, 0, 0, '', '', '', 0),
(13, 1, 11, 0, 0, '', '', '', 0),
(14, 5, 11, 0, 0, '', '', '', 0),
(15, 5, 11, 0, 0, '', '', '', 0),
(16, 10, 12, 0, 0, '', '', '', 0),
(17, 10, 12, 0, 0, '', '', '', 0),
(18, 10, 12, 0, 0, '', '', '', 0),
(19, 10, 12, 0, 0, '', '', '', 0),
(20, 1, 10, 0, 0, '', '', '', 0),
(21, 1, 10, 1, 1, '', '', '', 0),
(22, 1, 10, 0, 0, '', '', '', 0),
(23, 1, 10, 1, 0, '', '', '', 0),
(24, 1, 10, 1, 0, '', '', '', 0),
(25, 1, 10, 1, 0, '', '', '', 0),
(26, 1, 10, 1, 1, '', '', '', 0),
(27, 5, 10, 0, 0, '', '', '', 0),
(28, 10, 11, 0, 0, '', '', '', 0),
(29, 5, 10, 0, 0, '', '', '', 0),
(30, 5, 10, 0, 0, '', '', '', 0),
(31, 5, 10, 0, 0, '', '', '', 0),
(32, 10, 11, 0, 0, '', '', '', 0),
(33, 10, 10, 0, 0, '', '', '', 0),
(34, 10, 10, 0, 0, '', '', '', 0),
(35, 10, 10, 0, 0, '', '', '', 0),
(36, 10, 10, 0, 0, '', '', '', 0),
(37, 10, 10, 0, 0, '', '', '', 0),
(38, 10, 10, 0, 0, '', '', '', 0),
(39, 10, 10, 0, 0, '', '', '', 0),
(40, 5, 10, 0, 0, '', '', '', 0),
(41, 5, 10, 0, 0, '', '', '', 0),
(42, 5, 10, 0, 0, '', '', '', 0),
(43, 5, 10, 0, 0, '', '', '', 0),
(44, 5, 10, 0, 0, '', '', '', 0),
(45, 5, 10, 0, 0, '', '', '', 0),
(46, 5, 10, 0, 0, '', '', '', 0),
(47, 5, 10, 0, 0, '', '', '', 0),
(48, 5, 10, 0, 0, '', '', '', 0),
(49, 5, 36, 0, 0, '', '', '', 0),
(50, 5, 34, 0, 0, '', '', '', 0),
(51, 5, 47, 0, 0, '', '', '', 0),
(52, 5, 47, 0, 0, '', '', '', 0),
(53, 5, 47, 0, 0, '', '', '', 0),
(54, 5, 47, 0, 0, '', '', '', 0),
(55, 5, 47, 0, 0, '', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `description` varchar(60) NOT NULL,
  `room_pic` varchar(350) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `room_pic`) VALUES
(25, 'fariha', 'anskhdiswkds', ''),
(26, 'fariha', 'anskhdiswkds', ''),
(27, 'fariha', 'anskhdiswkds', ''),
(28, 'fariha', 'anskhdiswkds', ''),
(29, 'fariha', 'anskhdiswkds', ''),
(30, 'fariha', 'anskhdiswkds', ''),
(31, 'fariha', 'anskhdiswkds', ''),
(32, 'fariha', 'anskhdiswkds', ''),
(33, 'fariha', 'anskhdiswkds', ''),
(38, 'promiii', 'cdlkhdisi', ''),
(39, 'promiii', 'cdlkhdisi', ''),
(40, 'ouo', 'hihoiugiluj', ''),
(44, 'ndsjn', 'clxkjnddx', 'kkkk.jpg'),
(45, 'ndsjn', 'clxkjnddx', 'kkkk.jpg'),
(46, 'ndsjn', 'clxkjnddx', 'kkkk.jpg'),
(47, 'kjh', 'lkhioi', '2ca07685226567323407d7c5d193e537.jpg'),
(48, 'kjh', 'lkhioi', '2ca07685226567323407d7c5d193e537.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(40) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `role` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`) VALUES
(1, 'Salman', 'salman@gmail.com', '2222', '1'),
(5, 'emwpo', 'feojf@fldif.com', '2222', '2'),
(10, 'ddddiiii', 'dms@dsd.com', '2222', '2'),
(11, 'dnsoid', 'sjoij@dnsi.gmail.com', '22222', '1'),
(12, 'mclsk', 'dsodd@nosi.com', '122', '2');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

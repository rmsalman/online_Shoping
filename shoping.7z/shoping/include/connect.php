<?php

session_start();
if(isset($_GET["logout"])){
     session_destroy();
}



$servername = "localhost";
$username = "root";
$password = "";
$db = "online_shoping";
$conn = new mysqli($servername, $username, $password,$db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 





?>

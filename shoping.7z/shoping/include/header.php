
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Hotel</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link rel="stylesheet" href="assets/css/bootstrap.min.css">

   <!-- <link rel="stylesheet" href="assets/css/style.css"> -->
  <script src="assets/bootstrap/js/bootstrap.min.js"></script>
  <script src="jquery/jquery.js"></script>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">WebSiteName</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="home.php">Home</a></li>
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Products<span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="#">product-1</a></li>
          <li><a href="#">product-2</a></li>
          <li><a href="#">product-3</a></li>
        </ul>
      </li>
      <li><a href="#">Contact Us</a></li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
    
        <?php 
if (isset($_SESSION['email'])){ 
?> 
    <li><a href="home.php?logout=1">logout</a></li>
<?php

}else {
 ?>

         <li><a href="signup.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
         <li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>


      <?php } ?>


    </ul>
  </div>
</nav>
  


</body>
</html>
<?PHP
error_reporting(0);
?>

<html>
	<body>
		<form action="" method="POST" enctype="multipart/form-data" >
				<input type="file" name="uploadfile" value="">
			
                <input type="submit" name="submit" value="upload File">

		</form>
	</body>
</html>
<?php
$folder="upload/";
 $filename= $_FILES["uploadfile"] ["name"];
 $tempname= $_FILES["uploadfile"] ["tmp_name"];
 $folder= "upload/". "$filename";

 move_uploaded_file($tempname, $folder);
 echo "<img src='$folder' height='200'width='200'/>";

?>
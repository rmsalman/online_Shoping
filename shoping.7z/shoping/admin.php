<?php
include('include/header.php');
include('include/connect.php');
?>


<?php

  if(isset($_SESSION['id'])){
      $akk=$_SESSION['id'];
    $sql = "SELECT * , users.id as uid , products.id as pid , users.name as uname , products.name as pname FROM `orders` JOIN users on orders.user_id = users.id JOIN products on orders.product_id = products.id";
    ?>
         

   <?php
						
						

	if (isset($_SESSION['role']) && $_SESSION['role'] !== 1){
         
         echo '<meta http-equiv="refresh" content="0;url=/shoping/">';

        }
    ?>




   <table class="table table-striped">
	<thead>
		<tr>
			<th>user_id</th>
			<th>product_id</th>
			<th>email</th>
			<th>password</th>
			<th>role</th>
			<th>uname</th>
			<th>description</th>
			<th>pname</th>
			<th>uid</th>
			<th>pid</th>
		
		</tr>
	</thead>
	<tbody>
	<?php
			$result = mysqli_query($conn, $sql);

			if (mysqli_num_rows($result) > 0) {

				?>
					
		            
					
			   <?php

			    
		            while($row = mysqli_fetch_assoc($result)) {

                ?>

           
		       <tr>

			 <td><?php echo $row["user_id"]; ?>	</td>
			 	 <td><?php echo $row["product_id"] ; ?></td> 
		       <td> <?php echo $row["email"] ; ?></td>
		       <td> <?php echo $row["password"] ; ?></td>
		       <td> <?php echo $row["role"] ; ?></td>
		       <td> <?php echo $row["uname"] ; ?></td>
		       <td> <?php echo $row["description"] ; ?></td>
		       <td> <?php echo $row["pname"] ; ?></td>
		       <td> <?php echo $row["uid"] ; ?></td>
		       <td> <?php echo $row["pid"] ; ?></td>
		       </tr>
		     	
			 		     
		     </div>
		  </div>


 <?php
            }
        }
    }else{
        	echo "error";
        }


?>
</thead>
<table>





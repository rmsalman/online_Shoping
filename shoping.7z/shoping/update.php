

<?php

include('include/header.php');
include('include/connect.php');

?>


<?php

	
	if(isset($_GET["description"])){
       
        
        $id = $_GET["id"];
		$descripton = $_GET["description"];
		$name = $_GET["name"];

       echo $sql = "UPDATE `products` SET `name`='$name', `Description`='$descripton' WHERE id = '$id'  ";

				
		if (mysqli_query($conn, $sql)) {
	   			 header('location:home.php');
		} else {
		    echo "Error updating record: " . mysqli_error($conn);
		}
	}

		$ee = $_GET["id"];
	    $sql = "SELECT * FROM `products` WHERE id='$ee' ";

	   $result = $conn->query($sql);

		if ($result->num_rows > 0) {
		    // output data of each row
		    while($row = $result->fetch_assoc()) {
		        $id = $row["id"];
		        $name = $row["name"];
		        $description= $row["description"];
		        
		    }
		} else {
		    echo "0 results";
		}




   ?>



<div class="container">
<br>
<h2>Product Update</h2>


	<form class="form" action="" method="GET">
		<div class="form-group">
	    <label>id</label>
	    <input type="text" name="id" class="form-control" placeholder="id" value="<?php echo $id ?>">
	  </div> 
	  <div class="form-group">
	    <label>Name</label>
	    <input type="text" name="name" class="form-control" placeholder="name" value="<?php echo $name?>">
	  </div>
	  <div class="form-group">
	    <label> Description</label>
	    <textarea class="form-control" name="description"  placeholder="Add Description" value="<?php echo $description ?>"></textarea>
	  </div>
	
			  <button type="submit" name="submit" class="btn btn-primary">Update</button>
	</form>

</div>